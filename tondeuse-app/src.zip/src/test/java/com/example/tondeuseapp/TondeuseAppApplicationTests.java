package com.example.tondeuseapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TondeuseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
